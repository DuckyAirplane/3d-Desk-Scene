﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;

	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() == 0) return;

	OBJECT_MATERIAL material;
	if (FindMaterial(materialTag, material))
	{
		m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
		m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
		m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	}
}



/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();   // for desk top (and later, laptop body, etc.)
	m_basicMeshes->LoadCylinderMesh();  // For lamp stand
	m_basicMeshes->LoadConeMesh();      // For lampshade
	m_basicMeshes->LoadSphereMesh();    // For bulb


	CreateGLTexture("textures/knife_handle.jpg", "wood");
	CreateGLTexture("textures/gold-seamless-texture.jpg", "gold");
	CreateGLTexture("textures/pavers.jpg", "pavers");
	CreateGLTexture("textures/stainless_end.jpg", "steelTex");
	CreateGLTexture("textures/drywall.jpg", "drywall");
	CreateGLTexture("textures/stainless.jpg", "stainless");
	CreateGLTexture("textures/abstract.jpg", "abstract");
	CreateGLTexture("textures/Keyboard.jpg", "keyboard");
	CreateGLTexture("textures/Screen.jpg", "screen");
	CreateGLTexture("textures/mouse.jpg", "mouse");   


	// ===================== LIGHTING (LAMP ONLY) =====================
	m_pShaderManager->setIntValue(g_UseLightingName, true);


	// ---- single point light INSIDE the shade ----
	m_pShaderManager->setVec3Value("lightSources[0].position",
		glm::vec3(-8.5f, 6.55f, -0.8f)); // lamp X/Z, just below rim
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.14f, 0.12f, 0.08f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(1.00f, 0.95f, 0.82f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.00f, 0.95f, 0.82f));
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 1.0f);

	// attenuation for a tight pool on the desk
	m_pShaderManager->setFloatValue("lightSources[0].attenuationConstant", 1.01f);
	m_pShaderManager->setFloatValue("lightSources[0].attenuationLinear", 1.01f);
	m_pShaderManager->setFloatValue("lightSources[0].attenuationQuadratic", 1.01f);


	// =================== END LIGHTING (LAMP ONLY) ====================





	// --- STEP 2a: Register a shiny floor material ---
	OBJECT_MATERIAL m;
	m.tag = "floor";
	m.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	m.ambientStrength = 0.35f;     // matches your default ambient strength
	m.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	m.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	m.shininess = 64.0f;     // higher = tighter specular highlight
	m_objectMaterials.push_back(m);

	// --- MATERIAL: Wood (used by stand + cone) ---
	OBJECT_MATERIAL mw;
	mw.tag = "wood";
	mw.ambientColor = glm::vec3(0.60f, 0.40f, 0.30f);
	mw.ambientStrength = 0.30f;   // a little lift so it’s not too dark
	mw.diffuseColor = glm::vec3(0.60f, 0.40f, 0.30f);
	mw.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	mw.shininess = 8.0f;    // subtle highlight
	m_objectMaterials.push_back(mw);

	// --- MATERIAL: Gold (used by lampshade) ---
	OBJECT_MATERIAL mg;
	mg.tag = "gold";
	mg.ambientColor = glm::vec3(1.00f, 0.92f, 0.60f);
	mg.ambientStrength = 0.70f;   // bump ambient so the dark side isn’t pitch black
	mg.diffuseColor = glm::vec3(1.00f, 0.92f, 0.60f);
	mg.specularColor = glm::vec3(0.90f, 0.90f, 0.80f);
	mg.shininess = 64.0f;   // tighter highlight
	m_objectMaterials.push_back(mg);

	//-- MATERIAL: Steel (used for table legs)
	OBJECT_MATERIAL ms;
	ms.tag = "steel";
	ms.ambientColor = glm::vec3(0.85f, 0.85f, 0.85f);
	ms.ambientStrength = 0.35f;
	ms.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	ms.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ms.shininess = 128.0f;   // tight highlight -> metal look
	m_objectMaterials.push_back(ms);

}



/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

    //************************************************************************************************ FLOOR *************************************************************************************//
	scaleXYZ = glm::vec3(30.0f, 1.0f, 15.0f);
	XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;
	// center it under the desk (desk center is at x = -2.1)
	positionXYZ = glm::vec3(-2.1f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("floor");
	SetShaderTexture("pavers");
	SetTextureUVScale(24.0f, 16.0f);   // keep tiling crisp
	m_basicMeshes->DrawPlaneMesh();

	//************************************************************* Laptop ****************************************************************************************//

// Simple rectangle on top of desk (flush)
	scaleXYZ = glm::vec3(3.0f, 0.1f, 2.0f);   // width, half-thickness, depth
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Center Y = desk center Y + desk half-thickness + slab half-thickness
	positionXYZ = glm::vec3(-2.1f, 5.2f, 0.0f);


	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("steel");
	SetShaderTexture("stainless");   // was "keyboard"
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ===== KEYBOARD PLANE (debug color, clearly smaller than base) =====
	const float KB_EPS = 0.006f;    // lift above the box to avoid z-fighting

	// Make plane inset by 0.20 on each side -> 2.6 x 1.6
	glm::vec3 kbScale = glm::vec3(1.4f, 0.001f, 1.0f);
	glm::vec3 kbCenter = glm::vec3(-2.1f, 5.2f + 0.10f + KB_EPS - 0.05f, 0.0f);

	// Fix UV aspect ratio based on texture dimensions
	float texW = 798.0f;   // image width
	float texH = 461.0f;   // image height
	float aspect = texW / texH;   // ~1.73

	// Use a solid color first so size/edges are obvious
	SetTransformations(kbScale, 0.0f, 0.0f, 0.0f, kbCenter);
	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();


	// Laptop screen, exactly same size as base
	scaleXYZ = glm::vec3(3.0f, 2.0f, 0.1f);   // width = 3.0f, height = 2.0f, thin depth
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position: put it at the back edge of the base, standing up
	positionXYZ = glm::vec3(-2.1f, 6.2f, -1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("steel");
	SetShaderTexture("stainless");   // was "keyboard"
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


	// ---------------- MONITOR PLANE (in front of screen box) ----------------
	const float SCR_EPS_Z = 0.755f;      // tiny nudge to avoid z-fighting

	// Reuse the screen box's size/position we just set
	glm::vec3 scrBoxScale = glm::vec3(1.5f, 2.0f, 0.1f);       // same as above
	glm::vec3 scrBoxCenter = glm::vec3(-2.1f, 6.2f, -1.0f);     // same as above

	// Make the plane slightly smaller than the box
	glm::vec3 scrPlaneScale = glm::vec3(1.4f, 0.001f, 0.8f);


	// Place the plane on the front face of the box (toward +Z)
	glm::vec3 scrPlaneCenter = glm::vec3(
		scrBoxCenter.x,
		scrBoxCenter.y,
		scrBoxCenter.z + (scrBoxScale.z - scrPlaneScale.z) + SCR_EPS_Z
	);

	// Plane is XZ by default → rotate +90° around X to stand it upright
	SetTransformations(scrPlaneScale, 90.0f, 0.0f, 0.0f, scrPlaneCenter);

	// Use the screen texture (was SetShaderColor(...))
	SetShaderTexture("screen");
	SetTextureUVScale(1.0f, 1.0f);   // start here
	m_basicMeshes->DrawPlaneMesh();


	// ---------------- HINGE ----------------
	const float HINGE_R = 0.05f;          // thickness
	const float baseHalfW = 3.0f;           // from the base box scale X
	const float HINGE_LEN = baseHalfW;      // <-- was baseHalfW*2.0f (too long)
	const float HINGE_EPS_Z = 0.03f;          // tiny offset toward +Z

	glm::vec3 hingeScale = glm::vec3(HINGE_R, HINGE_LEN, HINGE_R); // (radius, length, radius)
	glm::vec3 hingeCenter = glm::vec3(-0.6f, 5.30f, -1.0f + HINGE_EPS_Z);

	SetTransformations(hingeScale, 0.0f, 0.0f, 90.0f, hingeCenter);
	SetShaderMaterial("steel");
	SetShaderTexture("stainless");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();



	//******************************************************************************** Mouse **********************************************************************************************************// 

// keep the same shape/position you already have
	scaleXYZ = glm::vec3(0.18f, 0.1f, 0.35f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.8f, 5.2f, 1.4f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// SOLID dark gray (no texture)
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);   // <-- 4 parameters (R,G,B,A)
	m_basicMeshes->DrawSphereMesh();

	//*************************************************************************** Chair  **************************************************************************************************************//
	const glm::vec3 CHAIR_CENTER = glm::vec3(-2.1f, 0.0f, 2.2f);

	// Dimensions
	const float SEAT_HEIGHT = 3.0f;
	const float SEAT_W = 2.0f;
	const float SEAT_D = 2.0f;
	const float SEAT_THK = 0.4f;

	const float BACK_H = 2.5f;
	const float BACK_THK = 0.30f;
	const float BACK_W = SEAT_W * 0.7f;
	const float LEG_R = 0.14f;

	// --- connector (define ONCE) ---
	const float backBottomY = SEAT_HEIGHT + SEAT_THK;
	const float connH = 1.70f;   // height
	const float connRX = 0.10f;   // X radius (very slim → flattened look)
	const float connRZ = 0.08f;   // Z radius (thin so it doesn't stick out)
	const float RAISE = 0.45f;   // vertical offset from seat

	// Leg placement
	const float LEG_IN_X = SEAT_W * 0.4f;
	const float LEG_IN_Z = SEAT_D * 0.4f;

	//***************************************************************************** Seat ******************************************************************************************************//
	scaleXYZ = glm::vec3(SEAT_W, SEAT_THK, SEAT_D);
	glm::vec3 seatPos = glm::vec3(CHAIR_CENTER.x, SEAT_HEIGHT, CHAIR_CENTER.z);
	SetTransformations(scaleXYZ, 0, 0, 0, seatPos);
	SetShaderTexture("wood");
	SetTextureUVScale(2.5f, 2.5f);
	m_basicMeshes->DrawCylinderMesh();

	/**************** Seat–Back Connector (single, flat) ****************/
	glm::vec3 connectorPos(
		CHAIR_CENTER.x,
		backBottomY + RAISE - connH * 0.5f,
		CHAIR_CENTER.z + SEAT_D - BACK_THK * 0.5f - 0.015f   // hug the backrest; negative keeps it from jutting forward
	);
	SetTransformations(glm::vec3(connRX, connH, connRZ), 10.0f, 0.0f, 0.0f, connectorPos);
	SetShaderTexture("drywall");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	//*************************************************************************** Cushion *******************************************************************************************************//
	scaleXYZ = glm::vec3(SEAT_W * 0.96f, SEAT_THK * 0.5f, SEAT_D * 0.96f);
	glm::vec3 cushionPos = glm::vec3(CHAIR_CENTER.x, SEAT_HEIGHT + SEAT_THK, CHAIR_CENTER.z);
	SetTransformations(scaleXYZ, 0, 0, 0, cushionPos);
	SetShaderTexture("abstract");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	/************************ Backrest ************************/
	scaleXYZ = glm::vec3(BACK_W, BACK_H, BACK_THK);
	float backTilt = 10.0f;
	glm::vec3 backPos(
		CHAIR_CENTER.x,
		SEAT_HEIGHT + SEAT_THK + BACK_H * 0.5f,
		CHAIR_CENTER.z + SEAT_D - BACK_THK * 0.5f
	);
	SetTransformations(scaleXYZ, backTilt, 0, 0, backPos);
	SetShaderTexture("abstract");
	SetTextureUVScale(4.0f, 4.0f);   // larger weave look
	m_basicMeshes->DrawCylinderMesh();

	/**************** CHAIR LEGS — attached & splayed ****************/
	SetShaderTexture("stainless");
	SetTextureUVScale(1.0f, 1.0f);

	const float seatBottomY = SEAT_HEIGHT - SEAT_THK * 0.08f;
	const float TOP_X = LEG_IN_X;
	const float TOP_Z = LEG_IN_Z;
	const float OUT_OFFSET = 0.10f;

	glm::vec3 top, base, d, n;  float L, rotX, rotZ;

	// FRONT-RIGHT
	top = glm::vec3(CHAIR_CENTER.x + TOP_X, seatBottomY, CHAIR_CENTER.z - TOP_Z);
	base = glm::vec3(top.x + OUT_OFFSET, 0.0f, top.z - OUT_OFFSET);
	d = top - base; L = glm::length(d); n = glm::normalize(d);
	rotX = glm::degrees(-atan2(n.z, n.y));  rotZ = glm::degrees(atan2(n.x, n.y));
	SetTransformations(glm::vec3(LEG_R, L, LEG_R), rotX, 0.0f, rotZ, base);
	m_basicMeshes->DrawCylinderMesh();

	// FRONT-LEFT
	top = glm::vec3(CHAIR_CENTER.x - TOP_X, seatBottomY, CHAIR_CENTER.z - TOP_Z);
	base = glm::vec3(top.x - OUT_OFFSET, 0.0f, top.z - OUT_OFFSET);
	d = top - base; L = glm::length(d); n = glm::normalize(d);
	rotX = glm::degrees(-atan2(n.z, n.y));  rotZ = glm::degrees(atan2(n.x, n.y));
	SetTransformations(glm::vec3(LEG_R, L, LEG_R), rotX, 0.0f, rotZ, base);
	m_basicMeshes->DrawCylinderMesh();

	// BACK-RIGHT
	top = glm::vec3(CHAIR_CENTER.x + TOP_X, seatBottomY, CHAIR_CENTER.z + TOP_Z);
	base = glm::vec3(top.x + OUT_OFFSET, 0.0f, top.z + OUT_OFFSET);
	d = top - base; L = glm::length(d); n = glm::normalize(d);
	rotX = glm::degrees(-atan2(n.z, n.y));  rotZ = glm::degrees(atan2(n.x, n.y));
	SetTransformations(glm::vec3(LEG_R, L, LEG_R), rotX, 0.0f, rotZ, base);
	m_basicMeshes->DrawCylinderMesh();

	// BACK-LEFT
	top = glm::vec3(CHAIR_CENTER.x - TOP_X, seatBottomY, CHAIR_CENTER.z + TOP_Z);
	base = glm::vec3(top.x - OUT_OFFSET, 0.0f, top.z + OUT_OFFSET);
	d = top - base; L = glm::length(d); n = glm::normalize(d);
	rotX = glm::degrees(-atan2(n.z, n.y));  rotZ = glm::degrees(atan2(n.x, n.y));
	SetTransformations(glm::vec3(LEG_R, L, LEG_R), rotX, 0.0f, rotZ, base);
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************************** Desk ******************************************************************************************/

	scaleXYZ = glm::vec3(18.0f, 0.25f, 5.0f);   // much bigger desk: wider (X) and deeper (Z)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// Keep desk top surface at same Y height as before
	positionXYZ = glm::vec3(-2.1f, 5.0f, 0.0f);

	// ---- Desk tuning (constants) ----
	const float DESK_WIDTH = 8.0f;   // X size (much bigger)
	const float DESK_DEPTH = 6.0f;   // Z size (much bigger)
	const float DESK_THICK = 0.25f;  // Y thickness (same)
	const float DESK_TOP_Y = 1.6f;   // same height as before

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply wood texture (unchanged)
	SetShaderMaterial("wood");
	SetShaderTexture("wood");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();


	/************ Simple Desk Legs (cylinders at corners) ************/
	const float LEG_RADIUS = 0.18f;   // X/Z scale of the cylinder (thickness)
	const float LEG_HEIGHT = 5.63f;    // Y scale (roughly desk height to floor)
	const float LEG_ANGLE = 30.0f;   // degrees away from vertical
	// Desk reference (center & half-extents) 
	const glm::vec3 DESK_CENTER = glm::vec3(-2.1f, 5.0f, 0.0f);
	const float HALF_X = 8.5f;          // how far the legs sit from center on X
	const float HALF_Z = 2.3f;          // how far the legs sit from center on Z
	// Push leg bases slightly outside so the angle feels correct
	const float BASE_OUT = 0.25f;

	// Steel look
	SetShaderMaterial("steel");
	SetShaderTexture("steelTex");
	SetTextureUVScale(1.0f, 1.0f);

	// Helper to draw one angled leg:
	// tipToward is the vector from leg base toward the desk center; we tilt opposite it
	auto DrawLeg = [&](glm::vec3 basePos, glm::vec3 tipToward)
		{
			// Normalize direction we’ll lean away from (i.e., outward from center)
			glm::vec3 d = glm::normalize(-tipToward); // outward
			// Convert that 3D outward direction into rotations: rotate around X for Z tilt,
			// and around Z for X tilt. Sign choices below lean the leg outward.
			float rotX = (d.z >= 0 ? -LEG_ANGLE : LEG_ANGLE) * std::abs(d.z);  // tilt toward ±Z
			float rotZ = (d.x >= 0 ? LEG_ANGLE : -LEG_ANGLE) * std::abs(d.x);  // tilt toward ±X

			// Scale: radius, height, radius. Position: put the base on the floor (y=0).
			glm::vec3 scaleXYZ(LEG_RADIUS, LEG_HEIGHT, LEG_RADIUS);
			float XrotationDegrees = rotX;
			float YrotationDegrees = 0.0f;
			float ZrotationDegrees = rotZ;

			// Draw
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, basePos);
			m_basicMeshes->DrawCylinderMesh();
		};

	// Compute leg base positions (on floor), slightly pushed out from the table footprint
	glm::vec3 FL = glm::vec3(DESK_CENTER.x - HALF_X - BASE_OUT, 0.0f, DESK_CENTER.z - HALF_Z - BASE_OUT); // front-left
	glm::vec3 FR = glm::vec3(DESK_CENTER.x + HALF_X + BASE_OUT, 0.0f, DESK_CENTER.z - HALF_Z - BASE_OUT); // front-right
	glm::vec3 BL = glm::vec3(DESK_CENTER.x - HALF_X - BASE_OUT, 0.0f, DESK_CENTER.z + HALF_Z + BASE_OUT); // back-left
	glm::vec3 BR = glm::vec3(DESK_CENTER.x + HALF_X + BASE_OUT, 0.0f, DESK_CENTER.z + HALF_Z + BASE_OUT); // back-right

	// Vectors pointing from each base toward desk center (used to decide tilt)
	glm::vec3 toCenterFL = DESK_CENTER - FL;
	glm::vec3 toCenterFR = DESK_CENTER - FR;
	glm::vec3 toCenterBL = DESK_CENTER - BL;
	glm::vec3 toCenterBR = DESK_CENTER - BR;

	// Draw the four legs
	DrawLeg(FL, toCenterFL);
	DrawLeg(FR, toCenterFR);
	DrawLeg(BL, toCenterBL);
	DrawLeg(BR, toCenterBR);

	/**************************************************************************************** Lamp ***************************************************************************************/

	// --- Stand (cylinder) ---
	scaleXYZ = glm::vec3(0.2f, 2.0f, 0.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-8.5f, 5.0f, -0.8f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood");
	m_basicMeshes->DrawCylinderMesh();

	// --- Lampshade top cap (cylinder) ---
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// keep same x/z as stand; raise by ~2.05 over the stand base
	positionXYZ = glm::vec3(-8.5f, 7.05f, -0.8f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("gold");
	SetShaderTexture("gold");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawCylinderMesh();

	// --- Cone body (flared part) ---
	scaleXYZ = glm::vec3(0.4f, 2.0f, 0.4f);
	XrotationDegrees = 0.0f;  // keep as you had it
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// same x/z as stand; base sits on desk top
	positionXYZ = glm::vec3(-8.5f, 5.0f, -0.8f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood");
	SetTextureUVScale(3.0f, 3.0f);
	m_basicMeshes->DrawConeMesh();
}

